# Critérios de Informação
## AIC E BIC
Comparação de modelos utilizando critério de informação Akaike (AIC) e Bayesian (BIC).
